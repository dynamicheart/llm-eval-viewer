# Sample task fixture

Used to verify archives emitted by the system tar command.
